import { test, expect, type Page, type Locator } from '@playwright/test';
import fs from 'node:fs';
import path from 'node:path';

/**
 * Universal same-origin website auditor + opt-in functional tester.
 * 
 * Step 1. Install Node.js (LTS version). - npm install
 * Step 2. Copy and extract the project folder.
 * Step 3. Open a terminal inside root directory (Website-Audit-Project)
 * Step 4. Install dependencies: - npm install
 * Step 5. Install Playwright browsers:- npx playwright install
 *
 * Run in powershell
 *   - goto root directory
 *   - run npx playwright test website-audit-functional.spec.ts
 *   - website-audit-functional.spec.ts is the name of the TypeScript (.ts) file that we intend to run
 * 
 * file structure
 *   - Website-Audit-Project/
 *     - tests/
 *       - website-audit-functional.spec.ts
 *    - playwright.config.ts
 *    - package.json
 *    - package-lock.json
 *    - .gitignore
 *    - playwright-report/
 *    - test-results/ Optional
 * 
 * Audit mode:
 *   - Crawls same-origin GET pages.
 *   - Inventories links, buttons, forms, inputs, iframes and images.
 *   - Records navigation failures, failed requests, page errors and console errors.
 *
 * Functional mode (opt-in):
 *   - Tests only buttons explicitly marked data-test-safe="true".
 *   - Tests only forms explicitly marked data-test-safe="true".
 *   - Checks native required-field validation and can fill common input types.
 *   - Does not submit forms unless ALLOW_FORM_SUBMISSIONS=true.
 *   - When submission is allowed, use a dedicated test/staging site and test data.
 *
 * Recommended application test hooks:
 *   <button data-test-safe="true" data-testid="open-dialog">Open</button>
 *   <form data-test-safe="true" data-testid="contact-form">...</form>
 *
 * Optional per-control test values:
 *   <input name="email" data-test-value="qa@example.test">
 *   <textarea name="message" data-test-value="Playwright test message">
 *
 * IMPORTANT:
 *   Generic websites cannot be tested safely by blindly clicking every button or
 *   submitting every form. Mark only non-destructive controls/forms as safe.
 *   Run against a website/environment you own or are authorized to test.
 */

type ImageInfo = {
  src: string;
  alt: string;
  complete: boolean;
  naturalWidth: number;
  loaded: boolean;
};

type PageAudit = {
  url: string;
  finalUrl?: string;
  status: number | string;
  title?: string;
  titleMissing?: boolean;
  metaDescription?: string;
  metaDescriptionMissing?: boolean;
  canonicalUrl?: string | null;
  headings?: string[];
  buttons?: Array<Record<string, unknown>>;
  links?: Array<Record<string, unknown>>;
  forms?: Array<Record<string, unknown>>;
  inputs?: Array<Record<string, unknown>>;
  iframes?: Array<Record<string, unknown>>;
  images?: ImageInfo[];
  brokenImages?: ImageInfo[];
  missingImageAlt?: ImageInfo[];
  pageErrors?: string[];
  consoleErrors?: string[];
  failedRequests?: string[];
  functionalTests?: FunctionalResult[];
  error?: string;
  screenshot?: string;
};

type FunctionalResult = {
  kind: 'button' | 'form';
  name: string;
  status: 'passed' | 'failed' | 'skipped';
  details: string;
};

const BASE_URL = process.env.BASE_URL ?? 'https://en.wikipedia.org/wiki/Flower';
const START_URL = process.env.START_URL ?? BASE_URL;
const MAX_PAGES = Number(process.env.MAX_PAGES ?? 10);
const NAVIGATION_TIMEOUT = Number(process.env.NAVIGATION_TIMEOUT ?? 30_000);
const PAGE_SETTLE_MS = Number(process.env.PAGE_SETTLE_MS ?? 500);
const FAIL_ON_BROKEN_PAGES = process.env.FAIL_ON_BROKEN_PAGES === 'true';

// Functional testing is deliberately disabled unless explicitly enabled.
const ENABLE_FUNCTIONAL_TESTS = process.env.ENABLE_FUNCTIONAL_TESTS === 'true';
// Form submission can change data. Enable only on a dedicated test/staging system.
const ALLOW_FORM_SUBMISSIONS = process.env.ALLOW_FORM_SUBMISSIONS === 'true';
const TEST_EMAIL = process.env.TEST_EMAIL ?? 'playwright-qa@example.test';
const TEST_PHONE = process.env.TEST_PHONE ?? '5550100123';
const TEST_TEXT = process.env.TEST_TEXT ?? 'Playwright automated test';
const REPORT_DIR = process.env.REPORT_DIR ?? 'reports';

if (!Number.isInteger(MAX_PAGES) || MAX_PAGES < 1) {
  throw new Error('MAX_PAGES must be a positive integer.');
}

let base: URL;
let start: URL;
try {
  base = new URL(BASE_URL);
  start = new URL(START_URL, base);
} catch {
  throw new Error(`Invalid BASE_URL or START_URL. BASE_URL=${BASE_URL}, START_URL=${START_URL}`);
}

if (!['http:', 'https:'].includes(base.protocol)) {
  throw new Error('BASE_URL must use http:// or https://');
}
if (start.origin !== base.origin) {
  throw new Error('START_URL must be on the same origin as BASE_URL.');
}

const ORIGIN = base.origin;

function normalizeUrl(destination: string): string | null {
  try {
    const parsed = new URL(destination, base);
    if (parsed.origin !== ORIGIN) return null;
    if (!['http:', 'https:'].includes(parsed.protocol)) return null;
    parsed.hash = '';
    if (parsed.pathname.length > 1) {
      parsed.pathname = parsed.pathname.replace(/\/+$/, '');
    }
    return parsed.href;
  } catch {
    return null;
  }
}

function safeFilePart(value: string): string {
  return value
    .replace(/^https?:\/\//, '')
    .replace(/[^a-zA-Z0-9_-]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 70) || 'website';
}

function escapeHtml(value: unknown): string {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function isVisible(element: HTMLElement): boolean {
  return !!(element.offsetWidth || element.offsetHeight || element.getClientRects().length);
}

async function collectPageDetails(
  page: Page,
  url: string,
  status: number | string,
  pageErrors: string[],
  consoleErrors: string[],
  failedRequests: string[],
): Promise<PageAudit> {
  const title = await page.title().catch(() => '');
  const metaDescription = await page.locator('meta[name="description"]')
    .getAttribute('content').catch(() => null);
  const canonicalUrl = await page.locator('link[rel="canonical"]')
    .getAttribute('href').catch(() => null);

  const headings = (await page.locator('h1, h2, h3, h4, h5, h6')
    .allTextContents().catch(() => []))
    .map(text => text.trim()).filter(Boolean);

  const buttons = await page.locator(
    'button, input[type="button"], input[type="submit"], input[type="reset"]',
  ).evaluateAll(elements => elements.map(element => {
    const el = element as HTMLButtonElement;
    return {
      text: (el.innerText || el.value || '').trim(),
      type: el.type,
      visible: !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length),
      enabled: !el.disabled,
      ariaLabel: el.getAttribute('aria-label'),
      id: el.id,
      testSafe: el.getAttribute('data-test-safe') === 'true',
      testId: el.getAttribute('data-testid'),
    };
  })).catch(() => []);

  const links = await page.locator('a[href]').evaluateAll(elements => elements.map(element => {
    const el = element as HTMLAnchorElement;
    return {
      text: el.innerText.trim(),
      href: el.href,
      target: el.target || null,
      visible: !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length),
    };
  })).catch(() => []);

  const forms = await page.locator('form').evaluateAll(elements => elements.map(element => {
    const form = element as HTMLFormElement;
    return {
      action: form.action,
      method: (form.method || 'get').toUpperCase(),
      id: form.id,
      name: form.name,
      visible: isVisible(form),
      fields: form.querySelectorAll('input, textarea, select, button').length,
      testSafe: form.getAttribute('data-test-safe') === 'true',
      testId: form.getAttribute('data-testid'),
    };
  })).catch(() => []);

  const inputs = await page.locator('input, textarea, select').evaluateAll(elements =>
    elements.map(element => {
      const el = element as HTMLInputElement;
      return {
        tag: el.tagName.toLowerCase(),
        type: el.type || el.tagName.toLowerCase(),
        name: el.name,
        id: el.id,
        placeholder: el.getAttribute('placeholder'),
        required: el.required,
        disabled: el.disabled,
        visible: !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length),
        ariaLabel: el.getAttribute('aria-label'),
      };
    }),
  ).catch(() => []);

  const iframes = await page.locator('iframe').evaluateAll(elements =>
    elements.map(element => ({
      src: (element as HTMLIFrameElement).src,
      title: element.getAttribute('title'),
    })),
  ).catch(() => []);

  const images: ImageInfo[] = await page.locator('img').evaluateAll(elements =>
    elements.map(element => {
      const img = element as HTMLImageElement;
      return {
        src: img.currentSrc || img.src,
        alt: img.alt,
        complete: img.complete,
        naturalWidth: img.naturalWidth,
        loaded: img.complete && img.naturalWidth > 0,
      };
    }),
  ).catch(() => []);

  return {
    url,
    finalUrl: page.url(),
    status,
    title,
    titleMissing: !title.trim(),
    metaDescription: metaDescription ?? '',
    metaDescriptionMissing: !metaDescription?.trim(),
    canonicalUrl,
    headings,
    buttons,
    links,
    forms,
    inputs,
    iframes,
    images,
    brokenImages: images.filter(image => !image.loaded),
    missingImageAlt: images.filter(image => !image.alt.trim()),
    pageErrors: [...pageErrors],
    consoleErrors: [...consoleErrors],
    failedRequests: [...failedRequests],
    functionalTests: [],
  };
}

/**
 * Fill visible, enabled controls with deterministic test values.
 * data-test-value takes priority. Checkboxes/radios are checked only when
 * appropriate; file inputs and hidden inputs are intentionally skipped.
 */
async function fillFormFields(form: Locator): Promise<string[]> {
  const notes: string[] = [];
  const controls = form.locator('input, textarea, select');
  const count = await controls.count();

  for (let i = 0; i < count; i++) {
    const field = controls.nth(i);
    if (!(await field.isVisible().catch(() => false))) continue;
    if (!(await field.isEnabled().catch(() => false))) continue;

    const tag = await field.evaluate(el => el.tagName.toLowerCase());
    const type = (await field.getAttribute('type') ?? '').toLowerCase();
    const name = (await field.getAttribute('name')) ?? '';
    const customValue = await field.getAttribute('data-test-value');
    const required = await field.evaluate((el: HTMLInputElement) =>
      el.required || el.getAttribute('aria-required') === 'true',
    );

    if (type === 'hidden' || type === 'file' || type === 'submit' ||
        type === 'button' || type === 'reset' || type === 'image') continue;

    if (type === 'checkbox' || type === 'radio') {
      if (required || customValue === 'true') {
        await field.check().catch(error => notes.push(`Could not check ${name || `field ${i}`}: ${String(error)}`));
      }
      continue;
    }

    if (tag === 'select') {
      const options = await field.locator('option').evaluateAll(opts =>
        opts.map(o => ({ value: (o as HTMLOptionElement).value, disabled: (o as HTMLOptionElement).disabled })),
      );
      const choice = customValue ?? options.find(o => o.value && !o.disabled)?.value;
      if (choice !== undefined) {
        await field.selectOption(choice).catch(error => notes.push(`Could not select ${name || `field ${i}`}: ${String(error)}`));
      }
      continue;
    }

    let value = customValue;
    if (value === null) {
      if (type === 'email' || /email/i.test(name)) value = TEST_EMAIL;
      else if (type === 'tel' || /phone|mobile/i.test(name)) value = TEST_PHONE;
      else if (type === 'number' || type === 'range') {
        value = await field.getAttribute('min') ?? '1';
      } else if (type === 'date') {
        value = '2026-01-15';
      } else if (type === 'url') {
        value = 'https://example.test';
      } else if (type === 'password') {
        value = 'Test-Only-Password-123!';
      } else if (type === 'search') {
        value = 'playwright test';
      } else if (type === 'color') {
        value = '#336699';
      } else if (type === 'time') {
        value = '10:30';
      } else if (type === 'month') {
        value = '2026-01';
      } else if (type === 'week') {
        value = '2026-W03';
      } else if (type === 'datetime-local') {
        value = '2026-01-15T10:30';
      } else if (tag === 'textarea') {
        value = TEST_TEXT;
      } else {
        value = TEST_TEXT;
      }
    }

    await field.fill(value).catch(error => notes.push(`Could not fill ${name || `field ${i}`}: ${String(error)}`));
  }
  return notes;
}

async function runButtonFunctionalTests(page: Page): Promise<FunctionalResult[]> {
  const results: FunctionalResult[] = [];
  const safeButtons = page.locator(
    'button[data-test-safe="true"]:visible:enabled, ' +
    'input[type="button"][data-test-safe="true"]:visible:enabled, ' +
    'input[type="submit"][data-test-safe="true"]:visible:enabled',
  );
  const count = await safeButtons.count();

  for (let i = 0; i < count; i++) {
    const button = safeButtons.nth(i);
    const name = (await button.innerText().catch(() => '')) ||
      (await button.getAttribute('aria-label')) ||
      (await button.getAttribute('data-testid')) ||
      `safe button ${i + 1}`;

    try {
      const beforeUrl = page.url();
      const beforeDialogs = await page.locator('[role="dialog"]:visible').count();
      await button.click({ timeout: 5_000 });
      await page.waitForTimeout(250);

      const afterUrl = page.url();
      const afterDialogs = await page.locator('[role="dialog"]:visible').count();
      const changedUrl = afterUrl !== beforeUrl;
      const dialogChanged = afterDialogs !== beforeDialogs;

      // A click completing without an exception verifies clickability, not business logic.
      // Use data-test-expect-url or data-test-expect-visible for an explicit assertion.
      const expectedUrl = await button.getAttribute('data-test-expect-url');
      const expectedVisible = await button.getAttribute('data-test-expect-visible');
      if (expectedUrl) {
        await expect(page).toHaveURL(new RegExp(expectedUrl.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')));
      }
      if (expectedVisible) {
        await expect(page.locator(expectedVisible)).toBeVisible();
      }

      results.push({
        kind: 'button',
        name,
        status: 'passed',
        details: `Click succeeded. URL changed: ${changedUrl}; visible dialog count changed: ${dialogChanged}.`,
      });
    } catch (error) {
      results.push({
        kind: 'button',
        name,
        status: 'failed',
        details: error instanceof Error ? error.message : String(error),
      });
    }
  }

  if (count === 0) {
    results.push({
      kind: 'button',
      name: 'Safe button selection',
      status: 'skipped',
      details: 'No visible, enabled buttons marked data-test-safe="true" were found.',
    });
  }
  return results;
}

async function runFormFunctionalTests(page: Page): Promise<FunctionalResult[]> {
  const results: FunctionalResult[] = [];
  const safeForms = page.locator('form[data-test-safe="true"]:visible');
  const count = await safeForms.count();

  for (let i = 0; i < count; i++) {
    const form = safeForms.nth(i);
    const name = (await form.getAttribute('data-testid')) ||
      (await form.getAttribute('id')) ||
      (await form.getAttribute('name')) ||
      `safe form ${i + 1}`;

    try {
      // First test browser-native required-field validation without submitting.
      const requiredFields = form.locator(
        'input[required], textarea[required], select[required], ' +
        'input[aria-required="true"], textarea[aria-required="true"], select[aria-required="true"]',
      );
      const requiredCount = await requiredFields.count();
      let validationDetails = 'No required fields found.';

      if (requiredCount > 0) {
        const firstRequired = requiredFields.first();
        const type = (await firstRequired.getAttribute('type') ?? '').toLowerCase();
        const tag = await firstRequired.evaluate(el => el.tagName.toLowerCase());

        // Clear a required text-like field to check validity state.
        if (tag !== 'select' && type !== 'checkbox' && type !== 'radio' && type !== 'file') {
          await firstRequired.fill('').catch(() => undefined);
          const validity = await firstRequired.evaluate((el: HTMLInputElement) => ({
            valid: el.checkValidity(),
            message: el.validationMessage,
          }));
          if (validity.valid) {
            throw new Error('Required field accepted an empty value; expected native validation to fail.');
          }
          validationDetails = `Required-field validation blocked empty value: ${validity.message || 'invalid'}.`;
        } else {
          validationDetails = 'Required field exists; native empty-state validity was not altered for this control type.';
        }
      }

      // Check native email-format validation before replacing the field with valid test data.
      const emailField = form.locator('input[type="email"]:visible:enabled').first();
      if (await emailField.count()) {
        await emailField.fill('not-an-email');
        const emailValidity = await emailField.evaluate((el: HTMLInputElement) => ({
          valid: el.checkValidity(),
          message: el.validationMessage,
        }));
        if (emailValidity.valid) {
          throw new Error('Email field accepted an invalid email address; expected native email validation to fail.');
        }
        validationDetails += ` Invalid email was rejected: ${emailValidity.message || 'invalid format'}.`;
      }

      const fillNotes = await fillFormFields(form);
      if (fillNotes.length) {
        validationDetails += ` Fill warnings: ${fillNotes.join(' | ')}`;
      }

      if (!ALLOW_FORM_SUBMISSIONS) {
        results.push({
          kind: 'form',
          name,
          status: 'passed',
          details: `${validationDetails} Fields were filled where supported. Submission was intentionally skipped (ALLOW_FORM_SUBMISSIONS is not true).`,
        });
        continue;
      }

      // Submissions are permitted only for explicitly marked forms and only when
      // the operator enables ALLOW_FORM_SUBMISSIONS on a test/staging environment.
      const action = await form.getAttribute('action');
      const resolvedAction = new URL(action || page.url(), page.url());
      if (resolvedAction.origin !== new URL(page.url()).origin) {
        throw new Error(`Refusing cross-origin form submission to ${resolvedAction.origin}.`);
      }

      const method = ((await form.getAttribute('method')) || 'get').toLowerCase();
      if (method !== 'get' && !ALLOW_FORM_SUBMISSIONS) {
        throw new Error('Non-GET form submission is disabled.');
      }

      const submit = form.locator(
        'button[type="submit"]:visible:enabled, input[type="submit"]:visible:enabled',
      ).first();

      if (await submit.count()) {
        await submit.click({ timeout: 5_000 });
      } else {
        await form.evaluate((el: HTMLFormElement) => el.requestSubmit());
      }

      await page.waitForLoadState('domcontentloaded', { timeout: 10_000 }).catch(() => undefined);
      await page.waitForTimeout(300);

      // Assert a generic outcome: browser navigation or a visible status/alert message.
      const hasFeedback = await page.locator(
        '[role="alert"]:visible, [role="status"]:visible, .success:visible, .error:visible',
      ).count();
      const navigated = page.url() !== resolvedAction.href && page.url() !== resolvedAction.toString();

      if (!hasFeedback && !navigated) {
        results.push({
          kind: 'form',
          name,
          status: 'skipped',
          details: 'Form was submitted, but no generic success/error feedback or clear navigation was detected. Add a site-specific success assertion.',
        });
      } else {
        results.push({
          kind: 'form',
          name,
          status: 'passed',
          details: `Submission interaction completed. Visible feedback elements: ${hasFeedback}.`,
        });
      }
    } catch (error) {
      results.push({
        kind: 'form',
        name,
        status: 'failed',
        details: error instanceof Error ? error.message : String(error),
      });
    }
  }

  if (count === 0) {
    results.push({
      kind: 'form',
      name: 'Safe form selection',
      status: 'skipped',
      details: 'No visible forms marked data-test-safe="true" were found.',
    });
  }
  return results;
}

function writeHtmlReport(
  filePath: string,
  report: PageAudit[],
  summary: Record<string, number>,
): void {
  const rows = report.map(item => `
    <tr>
      <td><a href="${escapeHtml(item.url)}">${escapeHtml(item.url)}</a></td>
      <td>${escapeHtml(item.status)}</td>
      <td>${escapeHtml(item.title ?? '')}</td>
      <td>${item.brokenImages?.length ?? 0}</td>
      <td>${item.missingImageAlt?.length ?? 0}</td>
      <td>${item.pageErrors?.length ?? 0}</td>
      <td>${item.consoleErrors?.length ?? 0}</td>
      <td>${escapeHtml(item.error ?? '')}</td>
    </tr>`).join('');

  const functionalRows = report.flatMap(item => (item.functionalTests ?? []).map(result => `
    <tr>
      <td>${escapeHtml(item.url)}</td>
      <td>${escapeHtml(result.kind)}</td>
      <td>${escapeHtml(result.name)}</td>
      <td>${escapeHtml(result.status)}</td>
      <td>${escapeHtml(result.details)}</td>
    </tr>`)).join('');

  const html = `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Website audit and functional test report</title>
<style>
body{font:14px Arial,sans-serif;margin:24px;color:#222}
table{border-collapse:collapse;width:100%;margin-top:20px}
th,td{border:1px solid #ddd;padding:8px;text-align:left;vertical-align:top;overflow-wrap:anywhere}
th{background:#f3f3f3}.summary{display:flex;gap:18px;flex-wrap:wrap}
.metric{padding:12px;background:#f4f6f8;border-radius:6px}
</style></head><body>
<h1>Website audit and functional test report</h1>
<div class="summary">${Object.entries(summary).map(([key, value]) =>
    `<div class="metric"><strong>${escapeHtml(key)}</strong><br>${value}</div>`).join('')}</div>
<h2>Page audit</h2>
<table><thead><tr><th>URL</th><th>Status</th><th>Title</th><th>Broken images</th><th>Missing alt</th><th>JS errors</th><th>Console errors</th><th>Navigation error</th></tr></thead><tbody>${rows}</tbody></table>
<h2>Functional tests</h2>
<table><thead><tr><th>URL</th><th>Type</th><th>Control</th><th>Result</th><th>Details</th></tr></thead><tbody>${functionalRows || '<tr><td colspan="5">No functional tests executed.</td></tr>'}</tbody></table>
<p>Generated ${new Date().toISOString()}.</p>
</body></html>`;
  fs.writeFileSync(filePath, html, 'utf8');
}

test('Universal website audit and opt-in functional tests', async ({ browser }) => {
  test.setTimeout(0);
  fs.mkdirSync(REPORT_DIR, { recursive: true });

  const context = await browser.newContext({
    viewport: { width: 1365, height: 900 },
    ignoreHTTPSErrors: false,
  });
  const page = await context.newPage();
  page.setDefaultNavigationTimeout(NAVIGATION_TIMEOUT);
  page.setDefaultTimeout(10_000);

  const visited = new Set<string>();
  const queue: string[] = [normalizeUrl(start.href)!];
  const report: PageAudit[] = [];
  const brokenPages: PageAudit[] = [];
  const siteSlug = safeFilePart(ORIGIN);

  try {
    while (queue.length > 0 && visited.size < MAX_PAGES) {
      const url = queue.shift()!;
      if (visited.has(url)) continue;
      visited.add(url);

      const pageErrors: string[] = [];
      const consoleErrors: string[] = [];
      const failedRequests: string[] = [];
      const onPageError = (error: Error) => pageErrors.push(error.message);
      const onConsole = (message: import('@playwright/test').ConsoleMessage) => {
        if (message.type() === 'error') consoleErrors.push(message.text());
      };
      const onRequestFailed = (request: import('@playwright/test').Request) => {
        failedRequests.push(
          `${request.method()} ${request.url()} - ${request.failure()?.errorText ?? 'request failed'}`,
        );
      };

      page.on('pageerror', onPageError);
      page.on('console', onConsole);
      page.on('requestfailed', onRequestFailed);

      console.log(`\n[${visited.size}/${MAX_PAGES}] Auditing ${url}`);

      try {
        const response = await page.goto(url, {
          waitUntil: 'domcontentloaded',
          timeout: NAVIGATION_TIMEOUT,
        });
        await page.waitForTimeout(PAGE_SETTLE_MS);

        if (new URL(page.url()).origin !== ORIGIN) {
          const item: PageAudit = {
            url,
            finalUrl: page.url(),
            status: response?.status() ?? 'Redirected outside allowed origin',
            error: 'Page redirected outside BASE_URL origin; page was not audited.',
          };
          report.push(item);
          console.warn(item.error, item.finalUrl);
          continue;
        }

        const status = response?.status() ?? 'No HTTP response';
        if (!response || (typeof status === 'number' && status >= 400)) {
          const item: PageAudit = {
            url,
            finalUrl: page.url(),
            status,
            error: 'Page failed to load or returned an HTTP error.',
            pageErrors: [...pageErrors],
            consoleErrors: [...consoleErrors],
            failedRequests: [...failedRequests],
          };
          const screenshot = path.join(REPORT_DIR, `${siteSlug}-${visited.size}-failure.png`);
          await page.screenshot({ path: screenshot, fullPage: true }).catch(() => undefined);
          if (fs.existsSync(screenshot)) item.screenshot = screenshot;
          report.push(item);
          brokenPages.push(item);
          continue;
        }

        const item = await collectPageDetails(
          page, url, status, pageErrors, consoleErrors, failedRequests,
        );

        if (ENABLE_FUNCTIONAL_TESTS) {
          item.functionalTests = [
            ...await runButtonFunctionalTests(page),
            ...await runFormFunctionalTests(page),
          ];
        }
        report.push(item);

        for (const link of item.links ?? []) {
          const destination = normalizeUrl(String(link.href ?? ''));
          if (destination && !visited.has(destination) && !queue.includes(destination)) {
            queue.push(destination);
          }
        }

        for (const form of item.forms ?? []) {
          if (String(form.method).toUpperCase() !== 'GET') continue;
          const destination = normalizeUrl(String(form.action ?? ''));
          if (destination && !visited.has(destination) && !queue.includes(destination)) {
            queue.push(destination);
          }
        }

        for (const iframe of item.iframes ?? []) {
          const destination = normalizeUrl(String(iframe.src ?? ''));
          if (destination && !visited.has(destination) && !queue.includes(destination)) {
            queue.push(destination);
          }
        }

        console.log(`Status: ${status} | Title: ${item.title}`);
        console.log(
          `Links: ${item.links?.length ?? 0} | Buttons: ${item.buttons?.length ?? 0} | Forms: ${item.forms?.length ?? 0}`,
        );
        console.log(`Images: ${item.images?.length ?? 0} | Broken images: ${item.brokenImages?.length ?? 0}`);
        if (item.functionalTests?.length) {
          console.log(`Functional tests: ${item.functionalTests.map(t => `${t.kind}:${t.status}`).join(', ')}`);
        }
      } catch (error) {
        const item: PageAudit = {
          url,
          status: 'Navigation error',
          error: error instanceof Error ? error.message : String(error),
          pageErrors: [...pageErrors],
          consoleErrors: [...consoleErrors],
          failedRequests: [...failedRequests],
        };
        const screenshot = path.join(REPORT_DIR, `${siteSlug}-${visited.size}-error.png`);
        await page.screenshot({ path: screenshot, fullPage: true }).catch(() => undefined);
        if (fs.existsSync(screenshot)) item.screenshot = screenshot;
        report.push(item);
        brokenPages.push(item);
        console.error('Navigation error:', url, item.error);
      } finally {
        page.off('pageerror', onPageError);
        page.off('console', onConsole);
        page.off('requestfailed', onRequestFailed);
      }
    }
  } finally {
    await context.close();
  }

  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const jsonFile = path.join(REPORT_DIR, `website-audit-${siteSlug}-${timestamp}.json`);
  const htmlFile = path.join(REPORT_DIR, `website-audit-${siteSlug}-${timestamp}.html`);

  const allFunctional = report.flatMap(item => item.functionalTests ?? []);
  const summary = {
    pagesVisited: visited.size,
    successfulPages: report.filter(item => typeof item.status === 'number' && item.status < 400).length,
    brokenPages: brokenPages.length,
    linksFound: report.reduce((sum, item) => sum + (item.links?.length ?? 0), 0),
    buttonsFound: report.reduce((sum, item) => sum + (item.buttons?.length ?? 0), 0),
    formsFound: report.reduce((sum, item) => sum + (item.forms?.length ?? 0), 0),
    brokenImages: report.reduce((sum, item) => sum + (item.brokenImages?.length ?? 0), 0),
    missingImageAlt: report.reduce((sum, item) => sum + (item.missingImageAlt?.length ?? 0), 0),
    javascriptErrors: report.reduce((sum, item) => sum + (item.pageErrors?.length ?? 0), 0),
    consoleErrors: report.reduce((sum, item) => sum + (item.consoleErrors?.length ?? 0), 0),
    failedRequests: report.reduce((sum, item) => sum + (item.failedRequests?.length ?? 0), 0),
    functionalTestsPassed: allFunctional.filter(t => t.status === 'passed').length,
    functionalTestsFailed: allFunctional.filter(t => t.status === 'failed').length,
    functionalTestsSkipped: allFunctional.filter(t => t.status === 'skipped').length,
  };

  fs.writeFileSync(
    jsonFile,
    JSON.stringify({ target: ORIGIN, generatedAt: new Date().toISOString(), summary, pages: report }, null, 2),
    'utf8',
  );
  writeHtmlReport(htmlFile, report, summary);

  console.log('\n========== WEBSITE AUDIT SUMMARY ==========');
  for (const [key, value] of Object.entries(summary)) console.log(`${key}: ${value}`);
  console.log(`Functional tests enabled: ${ENABLE_FUNCTIONAL_TESTS}`);
  console.log(`Form submissions allowed: ${ALLOW_FORM_SUBMISSIONS}`);
  console.log(`JSON report: ${jsonFile}`);
  console.log(`HTML report: ${htmlFile}`);
  console.log('===========================================');

  if (FAIL_ON_BROKEN_PAGES) {
    expect(brokenPages, 'Broken pages were discovered. See the generated reports.').toEqual([]);
  }

  if (ENABLE_FUNCTIONAL_TESTS) {
    expect(
      summary.functionalTestsFailed,
      'One or more opt-in functional tests failed. See the HTML/JSON reports.',
    ).toBe(0);
  }
});
